//
//  SyrInfoBox.h
//  SyrNative
//
//  Created by Anderson,Derek on 1/4/18.
//  Copyright © 2018 Anderson,Derek. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SyrInfoBox : UIView

@end
