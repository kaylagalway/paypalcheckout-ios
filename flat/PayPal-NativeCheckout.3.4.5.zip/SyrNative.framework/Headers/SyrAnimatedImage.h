//
//  SyrAnimatedImage.h
//  SyrNative
//
//  Created by Anderson,Derek on 1/16/18.
//  Copyright © 2018 Anderson,Derek. All rights reserved.
//
#import "SyrComponent.h"

@interface SyrAnimatedImage : SyrComponent

@end
