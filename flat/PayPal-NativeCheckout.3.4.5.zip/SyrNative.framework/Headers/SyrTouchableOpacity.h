//
//  SyrTouchableOpacity.h
//  SyrNative
//
//  Created by Anderson,Derek on 12/15/17.
//  Copyright © 2017 Anderson,Derek. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "SyrComponent.h"
#import "SyrEventHandler.h"

@interface SyrTouchableOpacity : NSObject

@end
