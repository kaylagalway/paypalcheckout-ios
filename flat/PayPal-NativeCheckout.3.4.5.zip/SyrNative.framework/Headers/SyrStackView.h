//
//  SyrStackedView.h
//  SyrNative
//
//  Created by Anderson,Derek on 11/18/17.
//  Copyright © 2017 Anderson,Derek. All rights reserved.
//

#import "SyrComponent.h"

@interface SyrStackView : SyrComponent

@end
