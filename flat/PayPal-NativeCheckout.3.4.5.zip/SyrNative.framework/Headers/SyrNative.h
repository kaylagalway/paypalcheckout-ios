//
//  SyrNative.h
//  SyrNative
//
//  Created by Anderson,Derek on 7/6/17.
//  Copyright © 2017 Anderson,Derek. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MouseNative.
FOUNDATION_EXPORT double SyrVersionNumber;

//! Project version string for MouseNative.
FOUNDATION_EXPORT const unsigned char SyrVersionString[];

#import "SyrRootView.h"
