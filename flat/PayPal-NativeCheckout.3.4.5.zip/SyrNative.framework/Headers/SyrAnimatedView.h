//
//  SyrAnimatedView.h
//  SyrNative
//
//  Created by Anderson,Derek on 10/20/17.
//  Copyright © 2017 Anderson,Derek. All rights reserved.
//

#import "SyrComponent.h"

@interface SyrAnimatedView : SyrComponent

@end
