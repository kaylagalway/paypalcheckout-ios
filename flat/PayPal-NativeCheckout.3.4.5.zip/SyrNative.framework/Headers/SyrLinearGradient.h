//
//  SyrLinearGradient.h
//  SyrNative
//
//  Created by Anderson,Derek on 11/17/17.
//  Copyright © 2017 Anderson,Derek. All rights reserved.
//

#import "SyrComponent.h"

@interface SyrLinearGradient : SyrComponent

@end
